//
//  AppDelegate.swift
//  NewsApp
//
//  Created by Vishal22 Sharma on 26/02/22.
//

import UIKit

@main
class AppDelegate: UIResponder, UIApplicationDelegate {
    
    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
        // Override point for customization after application launch.
        UIBarButtonItem.appearance().setTitleTextAttributes([.font: UIFont.systemFont(ofSize: 17, weight: .bold), .foregroundColor: UIColor.black], for: .normal)
        return true
    }
}
