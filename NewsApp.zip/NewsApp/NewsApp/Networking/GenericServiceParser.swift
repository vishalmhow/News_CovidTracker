//
//  GenericServiceParser.swift
//  NewsApp
//
//  Created by Vishal22 Sharma on 04/03/22.
//

import Foundation

class GenericServiceParser {
    
}
