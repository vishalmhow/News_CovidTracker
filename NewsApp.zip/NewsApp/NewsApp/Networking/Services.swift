//
//  Services.swift
//  NewsApp
//
//  Created by Vishal22 Sharma on 26/02/22.
//

import Foundation
import UIKit

class NewsServices {
    private let session = URLSession.shared
    private let decoder = JSONDecoder()
    
    // MARK: - API call to get News Headlines List
    func fetchNewsListWithAsyncURLSession() async throws -> [Article] {
        
        guard NetworkReachability.isConnectedToNetwork() else {
            throw NetworkError.noInternet
        }
        guard let url = URL(string: APIDetails.newsListUrl) else {
            throw NetworkError.apiFailure
        }
        
        // Use the async variant of URLSession to fetch data
        let (data, response) = try await session.data(from: url)
        
        guard let response = response as? HTTPURLResponse, response.statusCode == Constants.successCode else {
            throw NetworkError.invalidStatusCode
        }
        let newsData = try decoder.decode(NewsModel.self, from: data)
        
        return newsData.articles
    }
    
    // MARK: - API call to get US state list
    func fetchStateListWithAsyncURLSession() async throws -> [State] {
        guard NetworkReachability.isConnectedToNetwork() else {
            throw NetworkError.noInternet
        }
        guard let url = APIDetails.covidStateUrl else {
            throw NetworkError.apiFailure
        }
        
        // Use the async variant of URLSession to fetch data
        let (data, response) = try await session.data(from: url)
        
        guard let response = response as? HTTPURLResponse, response.statusCode == Constants.successCode else {
            throw NetworkError.invalidStatusCode
        }
        let result = try decoder.decode(StateListResponse.self, from: data)
        
        return result.data
    }
    // MARK: - API call to get Covid Data
    func fetchCovidDataWithAsyncURLSession(url: URL) async throws -> [DayData] {
        guard NetworkReachability.isConnectedToNetwork() else {
            throw NetworkError.noInternet
        }
        // Use the async variant of URLSession to fetch data
        let (data, response) = try await session.data(from: url)
        
        guard let response = response as? HTTPURLResponse, response.statusCode == Constants.successCode else {
            throw NetworkError.invalidStatusCode
        }
        let result = try decoder.decode(CovidDataResponse.self, from: data)
        
        let models: [DayData] = result.data.compactMap {
            guard let date = DateFormatter.dayFormatter.date(from: $0.date), let value = $0.cases?.total.value else {
                return nil
            }
            return DayData(date: date, count: value)
        }
        return models
    }
    
}
