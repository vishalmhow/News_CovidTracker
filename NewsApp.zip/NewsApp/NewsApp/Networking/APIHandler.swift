//
//  HTTPClient.swift
//  NewsApp
//
//  Created by Vishal22 Sharma on 26/02/22.
//

import Foundation
// MARK: - Enum for error handling
enum NetworkError: Error {
    case noInternet
    case apiFailure
    case invalidStatusCode
    case decodingError
}
// MARK: - declared required urls
struct APIDetails {
    static let newsListUrl = "https://newsapi.org/v2/everything?q=tesla&from=\(Date().getPreviousdDay()?.string(format: "yyyy-MM-dd") ?? "yyyy-MM-dd")&sortBy=publishedAt&apiKey=27dd4fff59d54d28a1974af0d18e9e62"
    static let covidStateUrl = URL(string: "https://api.covidtracking.com/v2/states.json")
    static let covidTrackingUrl = "https://api.covidtracking.com/v2/us/daily.json"
    static let filterCovidCasesUrl = "https://api.covidtracking.com/v2/states/state_code/daily.json"
}
// MARK: - Declared data scopes for Covid data
enum DataScope {
    case national
    case state(State)
}
