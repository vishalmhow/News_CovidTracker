//
//  Constants.swift
//  NewsApp
//
//  Created by Vishal22 Sharma on 27/02/22.
//

import Foundation

// MARK: - Constants
struct Constants {
    static let newsCellReuseId = "newsCell"
    static let covidCellReuseId = "covidCell"
    static let filterCellReuseId = "filterCell"
    static let mainStorybaord = "Main"
    static let successCode  = 200
    static let covidTrackerButton = "Covid Tracker"
    static let dateFormate = "YYYY-MM-dd"
    static let covidViewController = "CovidViewController"
    static let selectStateViewController = "SelectStateViewController"
    static let viewShadowOpacity = 0.7
    static let viewShadowRadius = 7
    static let viewCornerRadius = 10
}
