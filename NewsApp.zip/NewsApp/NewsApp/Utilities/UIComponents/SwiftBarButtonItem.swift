//
//  SwiftBarButtonItem.swift
//  NewsApp
//
//  Created by Vishal22 Sharma on 27/02/22.
//

import Foundation
import UIKit

// MARK: - Generate UIBarButtonItem
class SwiftBarButtonItem: UIBarButtonItem {
    
    typealias ActionHandler = (UIBarButtonItem) -> Void
    var actionHandler: ActionHandler?
    
    convenience init(title: String?, style: UIBarButtonItem.Style, actionHandler: ActionHandler?) {
        self.init(title: title, style: style, target: nil, action: #selector(barButtonItemPressed(sender:)))
        target = self
        self.actionHandler = actionHandler
    }

    convenience init(barButtonSystemItem systemItem: UIBarButtonItem.SystemItem, actionHandler: ActionHandler?) {
        self.init(barButtonSystemItem: systemItem, target: nil, action: #selector(barButtonItemPressed(sender:)))
        target = self
        self.actionHandler = actionHandler
    }

    @objc private func barButtonItemPressed(sender: UIBarButtonItem) {
        actionHandler?(sender)
    }
}
