//
//  NewsCell.swift
//  NewsApp
//
//  Created by Vishal22 Sharma on 26/02/22.
//

import UIKit

class NewsCell: UITableViewCell {
    
    @IBOutlet private weak var bgView: UIView!
    @IBOutlet private weak var titleLabel: UILabel!
    @IBOutlet private weak var descriptionLabel: UILabel!
    @IBOutlet private weak var articleImageView: UIImageView!
    private let cellViewModel = NewsCellViewModel()
    
    // MARK: - Configure News Cell
    func configureNewsCell(newsArticle: Article?) {
        cellViewModel.newsArticle = newsArticle
        titleLabel.text = cellViewModel.newsArticle?.title
        descriptionLabel.text = cellViewModel.newsArticle?.articleDescription
        downloadImageFromUrl()
    }
    // MARK: - Configure News Cell
    private func downloadImageFromUrl() {
        self.cellViewModel.downloadImageFromUrl { [weak self] (articleImage) in
            DispatchQueue.main.async {
                self?.articleImageView.image = articleImage
            }
        }
    }
    // MARK: - Awake cell from nib
    override func awakeFromNib() {
        super.awakeFromNib()
        bgView.layer.shadowOffset = .zero
        bgView.layer.shadowOpacity = Float(Constants.viewShadowOpacity)
        bgView.layer.shadowRadius = CGFloat(Constants.viewShadowRadius)
        bgView.layer.cornerRadius = CGFloat(Constants.viewCornerRadius)
    }
    // MARK: - Configure cell
    func configureArticleImageView(articaleImage: UIImage) {
        self.articleImageView.image = nil
        DispatchQueue.main.async { [weak self] in
            self?.articleImageView.image = articaleImage
        }
    }
}
