//
//  FilterCell.swift
//  NewsApp
//
//  Created by Vishal22 Sharma on 27/02/22.
//

import UIKit

class FilterCell: UITableViewCell {
    
    @IBOutlet private weak var stateNameLabel: UILabel!
    
    // MARK: - Configure Filter Cell
    func configureFilterCell(stateName: String) {
        self.stateNameLabel.text = stateName
    }
}
