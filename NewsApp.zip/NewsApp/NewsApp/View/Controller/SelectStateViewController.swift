//
//  SelectStateViewController.swift
//  NewsApp
//
//  Created by Vishal22 Sharma on 27/02/22.
//

import UIKit

class SelectStateViewController: UIViewController {
    
    @IBOutlet private weak var filterTableView: UITableView!
    var completion: ((State) -> Void)?
    private let viewModel = SelectStateViewModel()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setupProperties()
        fetchStateList()
    }
    // MARK: - Setup required properties
    private func setupProperties() {
        self.navigationController?.navigationBar.isHidden = false
        navigationItem.leftBarButtonItem = SwiftBarButtonItem(
            barButtonSystemItem: .close,
            actionHandler: { [weak self] (_) in
                self?.didTapClose()
            }
        )
    }
    // MARK: - Close button tap action
    private func didTapClose() {
        self.navigationController?.popViewController(animated: true)
    }
    // MARK: - Get US States list
    private func fetchStateList() {
        self.viewModel.fetchStateList { (status, _) in
            if status {
                DispatchQueue.main.async {
                    self.filterTableView.reloadData()
                }
            }
        }
    }
}
// MARK: - UITableview Extention sot its delegates and DataSource Implementation
extension SelectStateViewController: UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.viewModel.stateList.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: Constants.filterCellReuseId, for: indexPath) as? FilterCell else {
            return UITableViewCell()
        }
        cell.configureFilterCell(stateName: self.viewModel.stateList[indexPath.row].name)
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        self.filterTableView.deselectRow(at: indexPath, animated: true)
        let state = self.viewModel.stateList[indexPath.row]
        completion?(state)
        self.navigationController?.popViewController(animated: true)
    }
}
