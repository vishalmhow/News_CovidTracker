//
//  CovidViewController.swift
//  NewsApp
//
//  Created by Vishal22 Sharma on 27/02/22.
//

import UIKit
import Charts

class CovidViewController: UIViewController {
    
    @IBOutlet private weak  var covidTableView: UITableView!
    @IBOutlet private weak var chartView: BarChartView!
    private let viewModel = CovidViewModel()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.setupViewProperties()
    }
    // MARK: - Setup required properties
    private func setupViewProperties() {
        self.navigationController?.navigationBar.tintColor = .black
        addFilterButton()
        fetchCovidData()
    }
    // MARK: - Get Covid Hitory Data
    private func fetchCovidData() {
        self.viewModel.fetchCovidData { (status, _) in
            if status {
                DispatchQueue.main.async {
                    self.chartView.data = self.viewModel.setupBarChartView()
                    self.covidTableView.reloadData()
                }
            }
        }
    }
    // MARK: - Adding Filter button for US state selection
    private func addFilterButton() {
        self.navigationItem.rightBarButtonItem = SwiftBarButtonItem(
            title: self.viewModel.getFilterButtonTitle(),
            style: .plain,
            actionHandler: { [weak self] (_) in
                self?.filterButtonTapped()
            }
        )
    }
    // MARK: - Filter Button Action
    private func filterButtonTapped() {
        guard let stateViewController = UIStoryboard.init(name: Constants.mainStorybaord, bundle: Bundle.main).instantiateViewController(withIdentifier: Constants.selectStateViewController) as? SelectStateViewController else {
            return
        }
        stateViewController.completion = { state in
            self.viewModel.scope = .state(state)
            _ = self.viewModel.getFilterButtonTitle()
            self.addFilterButton()
            self.fetchCovidData()
        }
        self.navigationController?.pushViewController(stateViewController, animated: true)
    }
}
// MARK: - UITableview Extention sot its delegates and DataSource Implementation
extension CovidViewController: UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.viewModel.dayData.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: Constants.covidCellReuseId, for: indexPath) as? CovidCell else {
            return UITableViewCell()
        }
        cell.configureCovidCell(covidData: self.viewModel.getStringFromDate(dayData: self.viewModel.dayData[indexPath.row]))
        return cell
    }
    
}
