//
//  ViewController.swift
//  NewsApp
//
//  Created by Vishal22 Sharma on 26/02/22.
//

import UIKit
import SafariServices

class NewsListViewController: UIViewController {
    
    @IBOutlet private weak var newsTableView: UITableView!
    private var refreshControl = UIRefreshControl()
    private var viewModel = NewsListViewModel()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setupProperties()
    }
    // MARK: - Setup required properties
    private func setupProperties() {
        self.navigationItem.rightBarButtonItem = SwiftBarButtonItem(
            title: Constants.covidTrackerButton,
            style: .plain,
            actionHandler: { [weak self] (_) in
                self?.covidButtonTapped()
            }
        )
        self.newsTableView.addSubview(self.refreshControl)
        self.refreshControl.addTarget(self, action: #selector(self.getNewsData), for: .valueChanged)
        self.getNewsData()
    }
    // MARK: - Covid Button Action
    private func covidButtonTapped() {
        guard let covidViewController = UIStoryboard.init(name: Constants.mainStorybaord, bundle: Bundle.main).instantiateViewController(withIdentifier: Constants.covidViewController) as? CovidViewController else {
            return
        }
        self.navigationController?.pushViewController(covidViewController, animated: true)
    }
    // MARK: - API call to get news Data
    @objc private func getNewsData() {
        self.viewModel.getNewsData { (_, _) in
            DispatchQueue.main.async {
                self.newsTableView.reloadData()
                self.refreshControl.endRefreshing()
            }
        }
    }
}
// MARK: - UITableview Extention sot its delegates and DataSource Implementation
extension NewsListViewController: UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.viewModel.newsArticles.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: Constants.newsCellReuseId, for: indexPath) as? NewsCell else {
            return UITableViewCell()
        }
        cell.configureNewsCell(newsArticle: viewModel.newsArticles[indexPath.row])
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let article = self.viewModel.newsArticles[indexPath.row]
        guard let url = URL(string: article.url ?? "") else {
            return
        }
        let config = SFSafariViewController.Configuration()
        let safariViewController = SFSafariViewController(url: url, configuration: config)
        safariViewController.modalPresentationStyle = .formSheet
        present(safariViewController, animated: true)
    }
}
