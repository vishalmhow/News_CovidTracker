//
//  CovidDataModel.swift
//  NewsApp
//
//  Created by Vishal22 Sharma on 27/02/22.
//

import Foundation

// MARK: - CovidDataResponse
struct CovidDataResponse: Codable {
    let data: [CovidDayData]
}

// MARK: - CovidDayData
struct CovidDayData: Codable {
    let cases: CovidCases?
    let date: String
}

// MARK: - CovidCases
struct CovidCases: Codable {
    let total: TotalCases
}

// MARK: - TotalCases
struct TotalCases: Codable {
    let value: Int?
}

// MARK: - DayData
struct DayData: Codable {
    let date: Date
    let count: Int
}
