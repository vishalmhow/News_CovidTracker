//
//  NewsCellViewModel.swift
//  NewsApp
//
//  Created by Vishal22 Sharma on 27/02/22.
//

import Foundation
import UIKit

// MARK: - NewsCellViewModel
class NewsCellViewModel: NSObject {
    var newsArticle: Article?
    private var service: ImageDownloader? = ImageDownloader()
    typealias serviceHandler = ((UIImage?) -> Void)
    
    convenience init(service: ImageDownloader?) {
        self.init()
        self.service = service
    }
    // MARK: - Download Image from Url
    func downloadImageFromUrl(completion: @escaping(serviceHandler)) {
        Task {
            do {
                if let imageUrl = URL(string: self.newsArticle?.urlToImage ?? "") {
                    let downloadedImage = try await service?.downloadImageWithAsyncURLSession(imageUrl: imageUrl) as UIImage?
                    completion(downloadedImage ?? UIImage())
                } else {
                    completion(nil)
                }
            } catch {
                completion(nil)
            }
        }
    }
    
}
