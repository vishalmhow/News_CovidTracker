//
//  NewsListViewModel.swift
//  NewsApp
//
//  Created by Vishal22 Sharma on 26/02/22.
//

import Foundation
import UIKit

class NewsListViewModel: ObservableObject {
    
    var newsArticles: [Article] = []
    private var service: NewsServices? = NewsServices()
    typealias serviceHandler = ((Bool, Error?) -> Void)
    
    convenience init(service: NewsServices?) {
        self.init()
        self.service = service
    }
    // MARK: - API call to get news headlines
    func getNewsData(completion: @escaping(serviceHandler)) {
        Task {
            do {
                newsArticles = try await service?.fetchNewsListWithAsyncURLSession() ?? []
                completion(true, nil)
            } catch {
                completion(false, error)
                print(error.localizedDescription)
            }
        }
    }
}
