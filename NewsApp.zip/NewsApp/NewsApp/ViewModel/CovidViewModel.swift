//
//  CovidViewModel.swift
//  NewsApp
//
//  Created by Vishal22 Sharma on 27/02/22.
//

import Foundation
import Charts

class CovidViewModel: NSObject {
    var scope: DataScope  = .national
    var dayData = [DayData]()
    private var covidTrackingUrl: String = APIDetails.covidTrackingUrl
    private var service: NewsServices? = NewsServices()
    typealias serviceHandler = ((Bool, Error?) -> Void)
    
    // MARK: - Get required number formatter / we can also update this as per requirement
    let numberFormatter: NumberFormatter = {
        let formatter = NumberFormatter()
        formatter.usesGroupingSeparator = true
        formatter.groupingSeparator = ","
        formatter.formatterBehavior =  .default
        formatter.locale = .current
        return formatter
    }()
    
    convenience init(service: NewsServices?) {
        self.init()
        self.service = service
    }
    // MARK: - Filter button action
    func getFilterButtonTitle() -> String {
        switch scope {
        case .national:
            covidTrackingUrl = APIDetails.covidTrackingUrl
            return "National"
        case .state(let state):
            covidTrackingUrl = APIDetails.filterCovidCasesUrl.replacingOccurrences(of: "state_code", with: state.statecode.lowercased(), options: .literal, range: nil)
            return state.name
        }
    }
    // MARK: - API call to get Covid History Data
    func fetchCovidData (completion: @escaping(serviceHandler)) {
        Task {
            do {
                dayData = try await service?.fetchCovidDataWithAsyncURLSession(url: URL(string: covidTrackingUrl) ?? URL(fileURLWithPath: "")) ?? []
                completion(true, nil)
            } catch {
                print(error.localizedDescription)
                completion(false, error)
            }
        }
    }
    // MARK: - Get String from Date
    func getStringFromDate(dayData: DayData) -> String {
        let dateString =  DateFormatter.prettyFormatter.string(from: dayData.date)
        let total = self.numberFormatter.string(from: NSNumber(value: dayData.count))
        
        return "\(dateString): \(total ?? "\(dayData.count)")"
    }
    // MARK: - Generate Data frame for Bar Chart setup
    func setupBarChartView() -> BarChartData {
        var entries: [BarChartDataEntry] = []
        let subSet = dayData.prefix(20)
        for index in 0..<subSet.count {
            let data = subSet[index]
            entries.append(.init(x: Double(index), y: Double(data.count)))
        }
        let dataSet = BarChartDataSet(entries: entries)
        dataSet.colors = ChartColorTemplates.joyful()
        let data: BarChartData = BarChartData(dataSet: dataSet)
        
        return data
    }
    
}
