//
//  SelectStateViewModel.swift
//  NewsApp
//
//  Created by Vishal22 Sharma on 27/02/22.
//

import Foundation

class SelectStateViewModel: NSObject {
    
    var stateList = [State]()
    private var service: NewsServices? = NewsServices()
    typealias serviceHandler = ((Bool, Error?) -> Void)
    
    convenience init(service: NewsServices?) {
        self.init()
        self.service = service
    }
    // MARK: - API call to get US state list
    func fetchStateList (completion: @escaping(serviceHandler)) {
        Task {
            do {
                self.stateList = try await service?.fetchStateListWithAsyncURLSession() ?? []
                completion(true, nil)
            } catch {
                print(error.localizedDescription)
                completion(false, error)
            }
        }
    }
}
