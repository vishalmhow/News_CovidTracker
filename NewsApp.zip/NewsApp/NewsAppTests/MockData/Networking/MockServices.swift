//
//  MockServices.swift
//  NewsAppTests
//
//  Created by Vishal22 Sharma on 27/02/22.
//

import Foundation
@testable import NewsApp

class MockNewsServices: NewsServices {
    
    public var response: Any?
    
    override func fetchNewsListWithAsyncURLSession() async throws -> [Article] {
        if (self.response as? NSError) != nil {
            throw NetworkError.invalidStatusCode
        } else {
            return response as? [Article] ?? []
        }
    }
    
    override func fetchCovidDataWithAsyncURLSession(url: URL) async throws -> [DayData] {
        if (self.response as? NSError) != nil {
            throw NetworkError.invalidStatusCode
        } else {
            return response as? [DayData] ?? []
        }
    }
    
    override func fetchStateListWithAsyncURLSession() async throws -> [State] {
        if (self.response as? NSError) != nil {
            throw NetworkError.invalidStatusCode
        } else {
            return response as? [State] ?? []
        }
    }
    
    func mockNewsData() -> [Article] {
        let bundle = Bundle(for: type(of: self))
        guard let url = bundle.url(forResource: "MockNewsData", withExtension: "json") else { return [] }
        guard let data = try? Data(contentsOf: url) else { return [] }
        let decoder = JSONDecoder()
        decoder.dateDecodingStrategy = .iso8601
        let newsData = try? decoder.decode(NewsModel.self, from: data)
        return newsData?.articles ?? []
    }
    
    func mockCovidData() -> [DayData] {
        let bundle = Bundle(for: type(of: self))
        guard let url = bundle.url(forResource: "MockCovidData", withExtension: "json") else { return [] }
        guard let data = try? Data(contentsOf: url) else { return [] }
        let decoder = JSONDecoder()
        decoder.dateDecodingStrategy = .iso8601
        let result = try? decoder.decode(CovidDataResponse.self, from: data)
        let models: [DayData] = result?.data.compactMap {
            guard let date = DateFormatter.dayFormatter.date(from: $0.date), let value = $0.cases?.total.value else {
                return nil
            }
            return DayData(date: date, count: value)
            // return models
        } ?? []
        return models
    }
    
    func mockStateData() -> [State] {
        let bundle = Bundle(for: type(of: self))
        guard let url = bundle.url(forResource: "MockStateData", withExtension: "json") else { return [] }
        guard let data = try? Data(contentsOf: url) else { return [] }
        let decoder = JSONDecoder()
        decoder.dateDecodingStrategy = .iso8601
        let result = try? decoder.decode(StateListResponse.self, from: data)
        return result?.data ?? []
    }

}
