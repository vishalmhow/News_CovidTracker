//
//  MockImageDownloader.swift
//  NewsAppTests
//
//  Created by Vishal22 Sharma on 27/02/22.
//

import Foundation
@testable import NewsApp
import UIKit

class MockImageDownloader: ImageDownloader {
    
    public var response: Any?
    public var image: Any?
    
    override func downloadImageWithAsyncURLSession(imageUrl: URL) async throws -> UIImage {
        if (self.response as? NSError) != nil {
            throw NetworkError.invalidStatusCode
        } else {
            let image = UIImage()
            return image
        }
    }
    
    func setArticleDataForSuccess() -> Article? {
        let article = Article(
            title: "",
            articleDescription: "",
            url: "",
            urlToImage: "https://nextbigfuture.s3.amazonaws.com/uploads/2022/02/teslatexas.jpeg"
        )
        return article
    }
    
    func setArticleDataForFailure() -> Article? {
        let article = Article(
            title: "",
            articleDescription: "",
            url: "",
            urlToImage: ""
        )
        return article
    }
}
