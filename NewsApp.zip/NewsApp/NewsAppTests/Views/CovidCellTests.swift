//
//  CovidCellTests.swift
//  NewsAppTests
//
//  Created by Vishal22 Sharma on 04/03/22.
//

import XCTest
@testable import NewsApp

class CovidCellTests: XCTestCase {
    private var covidCell: CovidCell?
    private var filterCell: FilterCell?
    
    func test_ConfigureCovidCell() throws {
        if let covidCell = covidCell {
            covidCell.configureCovidCell(covidData: "")
        }
    }
    func test_ConfigureFiterCell() throws {
        if let filterCell = filterCell {
            filterCell.configureFilterCell(stateName: "")
        }
    }
}
