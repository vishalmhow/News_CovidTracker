//
//  NewsCellViewModelTests.swift
//  NewsAppTests
//
//  Created by Vishal22 Sharma on 04/03/22.
//

import XCTest
@testable import NewsApp

class NewsCellViewModelTests: XCTestCase {

    var imageDownloader: MockImageDownloader!
    var viewModel: NewsCellViewModel!
    
    override func setUpWithError() throws {
        // Put setup code here. This method is called before the invocation of each test method in the class.
        try super.setUpWithError()
        
        imageDownloader = MockImageDownloader()
        viewModel = NewsCellViewModel(service: imageDownloader)
    }

    override func tearDownWithError() throws {
        // Put teardown code here. This method is called after the invocation of each test method in the class.
        
        imageDownloader = nil
        viewModel = nil
        
        try super.tearDownWithError()
    }
    
    func testGetImageFromUrlSuccess() throws {
        viewModel.newsArticle = imageDownloader.setArticleDataForSuccess()
        imageDownloader.response = UIImage()
        viewModel.downloadImageFromUrl { image in
            XCTAssertNotNil(image)
        }
    }
    
    func testGetImageFromUrlFailure() throws {
        viewModel.newsArticle = imageDownloader.setArticleDataForFailure()
        let response = NSError(domain: "", code: 500, userInfo: [NSLocalizedDescriptionKey: "API Error occurred"])
        imageDownloader.response = response
        viewModel.downloadImageFromUrl { image in
            XCTAssertNil(image)
        }
    }
}
