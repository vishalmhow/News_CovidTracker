//
//  ImageCacheTests.swift
//  NewsAppTests
//
//  Created by Vishal22 Sharma on 04/03/22.
//

import XCTest
@testable import NewsApp

class ImageCacheTests: XCTestCase {
    private let imageCache = ImageCache()
    
    func test_CacheImageSuccess() throws {
        if let imageUrl = URL(string: APIDetails.newsListUrl) {
            imageCache.storeImageInCache(downloadedImage: UIImage(), imageUrl: imageUrl)
        }
    }
    
    func test_GetImageFromCacheSuccess() throws {
        if let imageUrl = URL(string: APIDetails.newsListUrl) {
           let image = imageCache.getImageFromCache(imageUrl: imageUrl)
            print(image ?? UIImage())
        }
    }
}
