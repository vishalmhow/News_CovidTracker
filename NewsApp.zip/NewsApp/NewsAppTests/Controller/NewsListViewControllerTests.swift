//
//  NewsListViewControllerTests.swift
//  NewsAppTests
//
//  Created by Vishal22 Sharma on 26/02/22.
//

import XCTest
@testable import NewsApp

class NewsListViewControllerTests: XCTestCase {

    var newsServices: MockNewsServices!
    var viewModel: NewsListViewModel!
    
    override func setUpWithError() throws {
        // Put setup code here. This method is called before the invocation of each test method in the class.
        try super.setUpWithError()
        
        newsServices = MockNewsServices()
        viewModel = NewsListViewModel(service: newsServices)
    }

    override func tearDownWithError() throws {
        // Put teardown code here. This method is called after the invocation of each test method in the class.
        
        newsServices = nil
        viewModel = nil
        
        try super.tearDownWithError()
    }
    
    func testGetNewsDataSuccess() throws {
        
        newsServices.response = newsServices.mockNewsData()
        
        viewModel.getNewsData { (status, _) in
            XCTAssertTrue(status)
        }
    }
    
    func testGetNewsDataFailureAPIError() throws {
        
        let response = NSError(domain: "", code: 500, userInfo: [NSLocalizedDescriptionKey: "API Error occurred"])
        newsServices.response = response
        
        viewModel.getNewsData { (_, error) in
            XCTAssertTrue(error != nil)
        }
    }
    
}
